package com.example.geoalarm;

import android.Manifest;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import org.osmdroid.config.Configuration;
import org.osmdroid.events.MapEventsReceiver;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.MapEventsOverlay;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

public class MainActivity extends AppCompatActivity {
    private MapView map;
    private Marker marker;
    private GeoPoint target;
    private TextView info;
    private EditText distance;

    private final ActivityResultLauncher<String[]> permLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), r -> {
                if (Boolean.TRUE.equals(r.get(Manifest.permission.ACCESS_FINE_LOCATION))) enableMe();
            });

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Configuration.getInstance().setUserAgentValue(getPackageName());
        setContentView(R.layout.activity_main);

        info = findViewById(R.id.info);
        distance = findViewById(R.id.distance);
        map = findViewById(R.id.map);
        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setMultiTouchControls(true);
        map.getController().setZoom(15.0);
        map.getController().setCenter(new GeoPoint(40.4093, 49.8671));

        marker = new Marker(map);
        map.getOverlays().add(new MapEventsOverlay(new MapEventsReceiver() {
            @Override public boolean singleTapConfirmedHelper(GeoPoint p) { setTarget(p); return true; }
            @Override public boolean longPressHelper(GeoPoint p) { return false; }
        }));

        ((Button) findViewById(R.id.start)).setOnClickListener(v -> start());
        ((Button) findViewById(R.id.stop)).setOnClickListener(v -> {
            Intent i = new Intent(this, LocationService.class);
            i.setAction(LocationService.ACTION_STOP);
            startService(i);
        });

        String[] perms = Build.VERSION.SDK_INT >= 33
                ? new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.POST_NOTIFICATIONS}
                : new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
        permLauncher.launch(perms);
    }

    private void enableMe() {
        MyLocationNewOverlay me = new MyLocationNewOverlay(new GpsMyLocationProvider(this), map);
        me.enableMyLocation();
        me.runOnFirstFix(() -> runOnUiThread(() -> {
            if (me.getMyLocation() != null) map.getController().animateTo(me.getMyLocation());
        }));
        map.getOverlays().add(me);
    }

    private void setTarget(GeoPoint p) {
        target = p;
        marker.setPosition(p);
        if (!map.getOverlays().contains(marker)) map.getOverlays().add(marker);
        map.invalidate();
        info.setText(String.format("Target: %.6f, %.6f", p.getLatitude(), p.getLongitude()));
    }

    private void start() {
        String d = distance.getText().toString().trim();
        if (target == null || d.isEmpty()) {
            Toast.makeText(this, "Pick a point and enter distance", Toast.LENGTH_SHORT).show();
            return;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Allow location permission first", Toast.LENGTH_LONG).show();
            permLauncher.launch(new String[]{Manifest.permission.ACCESS_FINE_LOCATION});
            return;
        }
        Intent i = new Intent(this, LocationService.class);
        i.putExtra("lat", target.getLatitude());
        i.putExtra("lon", target.getLongitude());
        i.putExtra("radius", Double.parseDouble(d));
        startForegroundService(i);
        Toast.makeText(this, "Tracking started", Toast.LENGTH_SHORT).show();
    }

    @Override protected void onResume() { super.onResume(); map.onResume(); }
    @Override protected void onPause() { super.onPause(); map.onPause(); }
}
