package com.example.geoalarm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

public class LocationService extends Service {
    public static final String ACTION_STOP = "com.example.geoalarm.STOP";
    private static final String CH = "geoalarm";

    private FusedLocationProviderClient client;
    private LocationCallback callback;
    private MediaPlayer player;
    private double tLat, tLon, radius;
    private boolean fired = false;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) {
            shutdown();
            return START_NOT_STICKY;
        }
        tLat = intent.getDoubleExtra("lat", 0);
        tLon = intent.getDoubleExtra("lon", 0);
        radius = intent.getDoubleExtra("radius", 100);
        fired = false;

        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH, "GeoAlarm", NotificationManager.IMPORTANCE_HIGH));
        Notification n = buildNotification("Tracking... (radius " + (int) radius + " m)", false);
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } else {
            startForeground(1, n);
        }

        client = LocationServices.getFusedLocationProviderClient(this);
        callback = new LocationCallback() {
            @Override public void onLocationResult(LocationResult r) {
                Location l = r.getLastLocation();
                if (l == null || fired) return;
                float[] res = new float[1];
                Location.distanceBetween(l.getLatitude(), l.getLongitude(), tLat, tLon, res);
                if (res[0] <= radius) trigger();
            }
        };
        LocationRequest req = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 3000).build();
        try {
            client.requestLocationUpdates(req, callback, getMainLooper());
        } catch (SecurityException e) {
            shutdown();
        }
        return START_NOT_STICKY;
    }

    private void trigger() {
        fired = true;
        client.removeLocationUpdates(callback);
        getSystemService(NotificationManager.class).notify(1, buildNotification("You arrived! Tap Stop to silence.", true));
        try {
            player = new MediaPlayer();
            player.setDataSource(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
            player.setLooping(true);
            player.prepare();
            player.start();
        } catch (Exception ignored) {}
        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        v.vibrate(VibrationEffect.createWaveform(new long[]{0, 800, 400}, 0));
    }

    private Notification buildNotification(String text, boolean withStop) {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, LocationService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(this, CH)
                .setSmallIcon(android.R.drawable.ic_dialog_map)
                .setContentTitle("GeoAlarm")
                .setContentText(text)
                .setContentIntent(open)
                .setOngoing(true);
        b.addAction(android.R.drawable.ic_delete, "Stop", stopPi);
        return b.build();
    }

    private void shutdown() {
        if (client != null && callback != null) client.removeLocationUpdates(callback);
        if (player != null) { player.release(); player = null; }
        ((Vibrator) getSystemService(Context.VIBRATOR_SERVICE)).cancel();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override public void onDestroy() { shutdown(); super.onDestroy(); }
}
